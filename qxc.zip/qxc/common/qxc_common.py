import re
import data_operate.data_analysis_csv as dacsv
import main as cm

def contain_english(content):
    return bool(re.search('[a-zA-Z]', content))

def getNumFromTw(tw):
    count = 1
    tw_result = []
    str_content = dacsv.read_from_csv_data(cm.rfilename)
    if list.__sizeof__(str_content):
        print()
    for datarow in str_content:
        result_data = datarow[5] + datarow[8]
        tw_result.append(result_data)
        count+=1
    return tw_result