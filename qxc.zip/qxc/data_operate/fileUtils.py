import os
import operator

def IsNotExistFile(fileName):
    return os.access(fileName, os.F_OK)

def tw_sort(tw_dict):
    return sorted(tw_dict.items(),key=operator.itemgetter(1),reverse=True)