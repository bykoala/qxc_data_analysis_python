import csv
import sys
import common.qxc_common as qce
import data_operate.fileUtils as df
import dataFromNet.get_data_from_net as g

#读取csv文件
def read_from_csv(filename):
    result_data = []
    data = read_from_csv_data(filename)
    # if header:
        # print(header)
        # print("==============================")
    for datarow in data:
        result_data.append(listToString(datarow))
    return result_data

#切片转字符串
def listToString(str_content):
    result_data = "".join(str_content).replace('\t','')
    return result_data

#获取当前本地数据最新期数数
def getLatest(fileName):
    result_data = []
    data = read_from_csv_data(fileName)
    count = 1
    for datarow in data:
        if count > 1:
            break
        result_data.append(listToString(datarow)[:-7])
        count+=1
    return round(float(result_data[0]))

#获取当前本地数据，返回data
def read_from_csv_data(fileName):
    data = []
    result_data = []
    try:
        with open(fileName) as f:
            reader = csv.reader(f)
            # header = next(reader)
            data = [row for row in reader]
    except csv.Error as e:
        print('Error reading CSV file at line %s:%s',reader.line_num,e)
        sys.exit(-1)
    return data

#取tw数,end为距今的期数，如：10，则表示最近的10期tw
def twFromData(str_content,end):
    count = 1
    tw_result = []
    for datarow in str_content:
        if count > end and end > 0:
            break
        result_data = datarow[5] + datarow[8]
        tw_result.append(result_data)
        count+=1
    return tw_result

#将字符串写入csv文件
def write_to_csv(filename,content):
    if len(content)==0 or qce.contain_english(content):
        return
    try:
        with open(filename,'r+') as f:
            old = f.read()
            f.seek(0)
            f.write(content+'\n')
            f.write(old)
            # writeCSV = f.write(content+'\n')
            # writeCSV.writerow(content)
    except csv.Error as e:
        print('Error Write CSV %s',e)
        sys.exit(-1)

def write_csv_from_net(wfilename,start_num,end_num):
    #1.先判断wfilename文件是否存在，若不存在，则新建
    file_status = df.IsNotExistFile(wfilename)
    #file_status为true，表示文件已存在，则需获取本地文件里面的数据
    if file_status:
        latest_num = getLatest(wfilename)
        #end_num比latest_num大，表示有服务器有新的数据
        if end_num > latest_num and latest_num > 0:
            start_num = latest_num
        else:
            return
    for i in range(end_num,start_num,-1):
        print(start_num)
        url = ""
        if i<10000:
            url = '0'+ str(i)
        else:
            url = str(i)
        content = g.getUrlResponeContent("http://kaijiang.500.com/shtml/qxc/" + url + ".shtml")
        if content == "continue":
            continue
        content = url + "," + content
        print(content)
        write_to_csv(wfilename,content)
# data_analy(filename)
# twFromData(data)