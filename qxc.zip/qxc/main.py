import data_operate.data_analysis_csv
import data_operate.fileUtils as df

rfilename = '../data/getresult.csv'
wfilename = '../data/getresult.csv'
qijianshu=100

#1.先获取本地最新期数，然后判断是否继续向服务器请求新的数据
#2.如果有新的数据，则在第一行插入新数据
# mycsv.write_csv_from_net(wfilename,4100,19090)

#获取本地现有的第一行数据
# result = mycsv.getLatest(rfilename)

#最近N期的tw数
bt_result = data_operate.twFromData(data_operate.data_analysis_csv.read_from_csv(rfilename), qijianshu)
print(df.tw_sort(data_operate.data_analysis_csv.tw_count(bt_result)))
# mycsv.write_to_csv(wfilename,"123")
# print(content)
# print(mycsv.read_from_csv("data_csv.csv"))
# mycsv.twFromData(mycsv.read_from_csv(rfilename))