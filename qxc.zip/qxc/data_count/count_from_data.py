
def init_dict():
    tw_dict={}
    for i in range(0,10):
        for k in range(0,10):
            tw_dict[str(i)+str(k)]=0
    return tw_dict

def tw_count(data_list):
    tw_dict = init_dict()
    for tw in data_list:
        if tw_dict[tw] > 0:
            tw_dict[tw] += 1
        else:
            tw_dict[tw] = 1
    return tw_dict